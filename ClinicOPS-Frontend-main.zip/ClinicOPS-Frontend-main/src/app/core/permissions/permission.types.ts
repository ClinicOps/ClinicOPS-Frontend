export type PermissionString = `${string}:${string}:${string}`;
