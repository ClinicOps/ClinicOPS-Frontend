export interface UserDTO {
  userId: string;
  email: string;
  organizationId: string;
  clinicId: string;
  clinicName: string;
  clinicTimezone: string;
  role: string;
}
